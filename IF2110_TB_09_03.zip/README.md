# TubesAlstrukdat
## Tugas Besar Alstrukdat Kelas 3 Kelompok 9
### Anggota Kelompok:
#### 13519099 - Thomas Ferdinand Martin
#### 13519107 - Daffa Ananda Pratama Resyaly
#### 13519135 - Naufal Alexander Suryasumirat
#### 13519139 - I Gede Govindabhakta
#### 13519175 - Stefanus Jeremy Aslan

```
    LIST OF COMMANDS

    OUTSIDE GAME
    new
    exit
    load

    IN GAME
    ANYTIME
    w, a, s, d

    PREP
    build
    upgrade
    buy
    undo
    execute
    main
    extend

    MAIN
    serve
    repair
    detail
    office
    prepare
    save

    IN OFFICE
    Details
    Report
    Exit
```