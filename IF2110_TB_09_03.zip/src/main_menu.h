#ifndef MAINMENU_H
#define MAINMENU_H

#include "game.h"

int main_menu(); // Fungsi Main Menu

// buka menu new game
void new_game();

#endif